export default class K4Dialog extends Dialog {
}
