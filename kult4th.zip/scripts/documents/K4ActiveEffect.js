export default class K4ActiveEffect extends ActiveEffect {
}
