export default class K4ChatMessage extends ChatMessage {
}
